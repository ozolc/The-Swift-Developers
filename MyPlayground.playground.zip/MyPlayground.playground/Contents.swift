
struct Stack<Element> {
    
    var items = [Element] ()
    
    mutating func push(_ item: Element) {
        items.append(item)
    }
    
    mutating func pop() -> Element {
        return items.removeLast()
    }
}

var stackOfString = Stack<String>()

stackOfString.push("uno")
stackOfString.push("dos")
stackOfString.push("tres")
stackOfString.push("cuatro")


struct Person {
    var name: String
}

var stackOfPersons = Stack<Person>()
stackOfPersons.push(Person(name: "Jim"))
stackOfPersons.push(Person(name: "David"))
stackOfPersons.push(Person(name: "Tim"))

stackOfPersons.items

stackOfPersons.pop()

extension Stack {
    var topItem: Element? {
        return items.isEmpty ? nil : items[items.count - 1]
    }
}

stackOfString.topItem
