import Foundation

protocol OneProtocol {
    var name: String { get set }
    var age: String { get set }
    
//    func hello(text: String)
}

struct Parents: OneProtocol {
    var name: String
    var age: String
}

struct Kids: OneProtocol {
    var name: String
    var age: String
}

struct Cats: OneProtocol {
    var name: String
    var age: String
}

var parents1 = Parents(name: "Jack", age: "28")
var parents2 = Parents(name: "Jina", age: "25")
var kid = Kids(name: "Maksim", age: "5")
var cat = Cats(name: "Murzik", age: "3")

//var array: [Any] = [parents1, parents2, kid, cat]
//
//for value in array {
//    if let parent = value as? Parents {
//        print(parent.name)
//    } else if let kid = value as? Kids {
//        print(kid.name)
//    }
//}

var array: [OneProtocol] = [parents1, parents2, kid, cat]

func sortFamily(array: [OneProtocol]) {
    for value in array {
        print("\(value.name) - age \(value.age)")
    }
}

sortFamily(array: array)






