import UIKit
protocol BeingProtocol {
    func showJoints(amount joints: Int, for name: String)
}
extension BeingProtocol {
    func showJoints(amount joints: Int, for name: String) {
        print("У меня \(joints) конечности, так как я \(name).\n")
    }
}
protocol FlyableProtocol {
    func showWings()
}
extension FlyableProtocol {
    func showWings(amount wings: Int, for name: String) {
        print("У меня \(wings) крыла, так как я \(name).\n")
    }
}

class Human: BeingProtocol { }
let man1 = Human()
man1.showJoints(amount: 2, for: "человек")

class Bug: BeingProtocol {
    func showJoints(name: String) {
        print("Я \(name) и у меня четыря лапки.")
    }
}
let bug1 = Bug()
bug1.showJoints(name: "жук")

struct Fly: BeingProtocol, FlyableProtocol {
    func showWings() {
        print("Вызван реализованный метод из протокола FlyableProtocol")
    }
}
let fly1 = Fly()
fly1.showJoints(amount: 4, for: "муха")
fly1.showWings()
fly1.showWings(amount: 2, for: "муха")
